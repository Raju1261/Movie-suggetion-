
movie_db = {
    'action': ['Mad Max: Fury Road', 'John Wick', 'Gladiator'],
    'comedy': ['The Hangover', 'Superbad', 'Step Brothers'],
    'drama': ['Forrest Gump', 'The Shawshank Redemption', 'Fight Club'],
    'sci-fi': ['Inception', 'Interstellar', 'The Matrix'],
    'romance': ['Titanic', 'The Notebook', 'Pride & Prejudice']
}

def get_movies_by_genre(genre):
    return movie_db.get(genre.lower(), [])
