
from flask import Flask, render_template, request, redirect
from movie_data import get_movies_by_genre

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/genres')
def genre_selection():
    return render_template('genres.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    genre = request.form.get('genre')
    movies = get_movies_by_genre(genre)
    return render_template('recommend.html', movies=movies, genre=genre)

@app.route('/feedback', methods=['POST'])
def feedback():
    user_feedback = request.form.get('feedback')
    with open('feedback.txt', 'a') as f:
        f.write(user_feedback + '\n')
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
